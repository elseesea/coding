package com.packt.learnjava.ch05_stringsIoStreams;

public class Person2 {
    private int age;
    private String name;

    public Person2(int age, String name) {
        this.age = age;
        this.name = name;
    }
}
