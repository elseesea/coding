package com.packt.learnjava.ch12_gui;

import javafx.fxml.FXML;
import javafx.scene.text.Text;

public class HelloWorldController2 {
    @FXML
    public Text textUser;


}
