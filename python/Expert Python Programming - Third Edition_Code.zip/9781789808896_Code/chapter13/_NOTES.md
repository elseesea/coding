Map of example scripts to Chapter sections

* Macro-profiling
  * `cprofile_profiling.py`
  * `cprofile_decorator.py`

* Profiling memory
  * `graphing_backreferences.py`
  * `cyclic_references.py`
