Chapter 10, 11, and Appendix dont contain code files.
Softwares and Hardwares are provided in the chapters itself.