Map of example scripts to Chapter sections

* Python standard test tools (unittest)
  * `unittest_testing/test_primes.py`

* unittest alternatives (pytest)
  * `pytest_testing/test_primes.py`

3. Building a fake
  3.1 ./test_with_fake/test_mailer.py

4. Using mocks
  4.1 ./test_with_mock/test_mailer.py
  4.2 ./test_with_mock_patch/test_mailer.py
