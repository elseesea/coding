Map of example scripts to Chapter sections

* "The popular tools and techniques used for maintaining cross-version compatibility"
  * `example_compat.py`
