from django.utils.translation import ugettext as _
from django.db import models

# Create your models here.

MESSAGES = (
    _("Hello!"),
    _('Bye!'),
    _('Thank you!'),
)
