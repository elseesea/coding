Map of example scripts to Chapter sections

* Constants
  * `options.py`

* Properties:
  * `custom_container.py`

* Public and private variables
  * `private_variables.py`
  * `private_attributes.py`
