Map of example scripts to Chapter sections

* Common patterns
  * `example_with_version/setup.py`
  * `example_with_readme_conversion/setup.py`

* Namespace packages
  * `implicit_namespace_package/setup.py`
  * `explicit_namespace_package/setup.py`
