# example README

This is example of `README` file with package long description
using Markdown text markup. This will be translated to reStructuredText
on upload to PyPI.
