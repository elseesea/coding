Map of example scripts to Chapter sections

* Deterministic caching
  * `memoize_decorator.py`
  * `memoize_lru_cache.py`
