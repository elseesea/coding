Map of example scripts to Chapter sections

* Using the __new__() method to override instance creation process
  * `instance_counting.py`
  * `nonzero.py`

* Metaclasses
  * `metaclasses.py`

* Hy
  * `hyllo.hy`
  * `py_hyllo.py`