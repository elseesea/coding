Map of example scripts to Chapter sections

* Event-driven programming in GUIs
  * `tkinter_gui.py`

* Event-driven communication
  * `web_application.py`

* Subject-based style
  * `subject_based_style.py`

* Topic-based style
  * `topic_signaling_style.p`
